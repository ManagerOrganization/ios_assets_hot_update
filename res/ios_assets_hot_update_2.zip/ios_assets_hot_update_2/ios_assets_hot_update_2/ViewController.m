//
//  ViewController.m
//  ios_assets_hot_update_2
//
//  Created by 颜风 on 16/9/22.
//  Copyright © 2016年 iOS122. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+imageNamed_bundle_.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *sampleImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    /* test sample */
    //    NSString * bundlePath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"main.bundle"];
    //    NSBundle * mainBundle = [NSBundle bundleWithPath:bundlePath];
    //    NSString * imgPath = [mainBundle pathForResource:@"sample" ofType:@"png"];
    //    self.sampleImageView.image = [UIImage imageWithContentsOfFile: imgPath];
    
    /* code it self. */
//    NSString * bundlePath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"main.bundle"];
//    NSBundle * mainBundle = [NSBundle bundleWithPath:bundlePath];
//    NSString * imgPath = [mainBundle pathForResource:@"sample@3x" ofType:@"png"];
//    
//    UIImage * image;
//    static NSString * model;
//    
//    if (!model) {
//        model = [[UIDevice currentDevice]model];
//    }
//    
//    if ([model isEqualToString:@"iPad"]) {
//        NSData *imageData = [NSData dataWithContentsOfFile: imgPath];
//        image = [UIImage imageWithData:imageData scale:2.0];
//    }else{
//        image = [UIImage imageWithContentsOfFile: imgPath];
//    }
    
    /* use category. */
    UIImage * image = [UIImage imageNamed:@"sub/sample" bundle:@"main"];
    self.sampleImageView.image = image;
    
    NSLog(@"加载后的图片尺寸:%@",[NSValue valueWithCGSize:self.sampleImageView.image.size]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
