//
//  ViewController.m
//  ios_assets_hot_update_3
//
//  Created by 颜风 on 2016/10/3.
//  Copyright © 2016年 颜风. All rights reserved.
//

#import "ViewController.h"

#import "UIImage+imageNamed_bundle_.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *sampleImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    /* 原型代码. */
//    NSArray * LibraryPaths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
//    NSString * cacheBundleDir = [[LibraryPaths objectAtIndex:0] stringByAppendingFormat:@"/Caches/Patch/"];
//    
//    NSString * bundleName = @"main.bundle";
//    NSString * imgName = @"sample@3x";
//    
//    NSString * bundlePath = [cacheBundleDir stringByAppendingPathComponent: bundleName];
//    NSBundle * cacheMainBundle = [NSBundle bundleWithPath:bundlePath];
//    NSString * imgPath = [cacheMainBundle pathForResource:imgName ofType:@"png"];
//    UIImage * image = [UIImage imageWithContentsOfFile: imgPath];
//    self.sampleImageView.image = image;
    
    /* use category. */
    /* load from ipa */
//    UIImage * image = [UIImage imageNamed:@"sub/sample" bundle:@"main"];
//    self.sampleImageView.image = image;
//    
//    NSLog(@"加载后的图片尺寸:%@",[NSValue valueWithCGSize:self.sampleImageView.image.size]);
    
    /* load from cache. */
    UIImage * image = [UIImage imageNamed:@"sub/sample" bundle:@"main" cacheDir:@"patch/default"];
    self.sampleImageView.image = image;
    
    NSLog(@"加载后的图片尺寸:%@",[NSValue valueWithCGSize:self.sampleImageView.image.size]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
