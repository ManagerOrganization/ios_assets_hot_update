//
//  ViewController.m
//  ios_assets_hot_update_4
//
//  Created by 颜风 on 2016/10/3.
//  Copyright © 2016年 颜风. All rights reserved.
//

#import "ViewController.h"

#import "UIImage+imageNamed_bundle_.h"

@interface ViewController ()<NSURLSessionDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *sampleImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.    
    
    /* load from cache. */
    UIImage * image = [UIImage yf_imageNamed:@"sub/sample"];
    self.sampleImageView.image = image;
    
    NSLog(@"加载后的图片尺寸:%@",[NSValue valueWithCGSize:self.sampleImageView.image.size]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
