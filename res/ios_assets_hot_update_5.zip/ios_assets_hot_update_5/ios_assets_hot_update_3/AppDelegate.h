//
//  AppDelegate.h
//  ios_assets_hot_update_4
//
//  Created by 颜风 on 2016/10/3.
//  Copyright © 2016年 颜风. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

