//
//  ViewController.m
//  ios_assets_hot_update_4
//
//  Created by 颜风 on 2016/10/3.
//  Copyright © 2016年 颜风. All rights reserved.
//

#import "ViewController.h"

#import "UIImage+imageNamed_bundle_.h"

@interface ViewController ()<NSURLSessionDelegate>
@property (weak, nonatomic) IBOutlet UILabel *infoLabel;
@property (weak, nonatomic) IBOutlet UIImageView *sampleImageView;

@end

@implementation ViewController
- (IBAction)reset:(id)sender {
    __weak ViewController * weakSelf = self;
    
    [UIImage yf_reset:^(BOOL success, NSError *error) {
        if (success) {
            UIImage * image = [UIImage yf_imageNamed:@"sub/sample"];
            weakSelf.sampleImageView.image = image;
        }else
        {
            NSLog(@"reset error:%@", error);
        }
    }];
}

- (IBAction)onlineUpdate:(id)sender {
    __weak ViewController * weakSelf = self;
    [UIImage yf_updatePatchFrom:@"https://raw.githubusercontent.com/ios122/ios_assets_hot_update/master/res/patch_04.json" completionHandler:^(BOOL success, NSError *error) {
        if (success) {
            
            UIImage * image = [UIImage yf_imageNamed:@"sub/sample"];
            weakSelf.sampleImageView.image = image;
        }else
        {
            NSLog(@"update error:%@", error);
        }
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.    
    
    /* load from cache. */
    UIImage * image = [UIImage yf_imageNamed:@"sub/sample"];
    self.sampleImageView.image = image;
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    
    NSString* version=[infoDictionary objectForKey:@"CFBundleShortVersionString"];
    NSString* appName=[infoDictionary objectForKey:(NSString *)kCFBundleNameKey];
    self.infoLabel.text=[NSString stringWithFormat:@"%@ for iOS %@",appName,version];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
